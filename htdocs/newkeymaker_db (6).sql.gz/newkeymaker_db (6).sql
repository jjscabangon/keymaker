-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2024 at 02:02 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newkeymaker_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_ratings`
--

CREATE TABLE `app_ratings` (
  `app_rating_id` bigint(20) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `rating` decimal(2,1) NOT NULL,
  `date_posted` datetime NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `job_post_id` bigint(20) NOT NULL,
  `job_application_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `app_ratings`
--

INSERT INTO `app_ratings` (`app_rating_id`, `comment`, `rating`, `date_posted`, `user_id`, `job_post_id`, `job_application_id`) VALUES
(4, 'ok', 4.0, '2024-11-21 05:15:20', 2, 1, 17),
(5, 'good business', 4.0, '2024-11-21 05:19:26', 6, 8, 18),
(6, 'poor', 1.0, '2024-11-21 05:22:50', 6, 8, 18),
(7, 'ok', 2.0, '2024-11-21 05:41:42', 6, 8, 18),
(8, 'ok', 3.0, '2024-11-21 05:44:01', 6, 8, 18),
(9, 'ok', 3.0, '2024-11-21 05:45:11', 6, 8, 18),
(10, 'ok', 4.0, '2024-11-22 19:24:30', 2, 1, 20);

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `document_id` bigint(20) NOT NULL,
  `document_type` enum('business_permit','police_clearance') NOT NULL,
  `valid_until` datetime NOT NULL,
  `status` enum('pending','approved','declined','expired') NOT NULL,
  `approved_by` int(11) NOT NULL,
  `approved_at` datetime NOT NULL,
  `declined_by` int(11) NOT NULL,
  `declined_at` datetime NOT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employer_ratings`
--

CREATE TABLE `employer_ratings` (
  `employer_rating_id` bigint(20) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `rating` decimal(2,1) NOT NULL,
  `date_posted` datetime NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `target_user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employer_ratings`
--

INSERT INTO `employer_ratings` (`employer_rating_id`, `comment`, `rating`, `date_posted`, `user_id`, `target_user_id`) VALUES
(1, 'poor', 1.0, '2024-11-22 17:43:19', 3, 7),
(2, 'poor employer', 2.0, '2024-11-22 19:27:57', 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `employment_types`
--

CREATE TABLE `employment_types` (
  `employment_type_id` bigint(20) NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employment_types`
--

INSERT INTO `employment_types` (`employment_type_id`, `type_name`) VALUES
(1, 'Full-Time'),
(2, 'Part-Time'),
(3, 'Freelancing'),
(4, 'Side Hustle');

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker_ratings`
--

CREATE TABLE `jobseeker_ratings` (
  `jobseeker_rating_id` bigint(20) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `rating` decimal(2,1) NOT NULL,
  `date_posted` datetime NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `target_user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobseeker_ratings`
--

INSERT INTO `jobseeker_ratings` (`jobseeker_rating_id`, `comment`, `rating`, `date_posted`, `user_id`, `target_user_id`) VALUES
(7, 'good', 1.0, '2024-11-22 04:38:51', 3, 2),
(8, 'very good', 5.0, '2024-11-22 04:41:06', 7, 6),
(9, 'good', 5.0, '2024-11-22 16:13:55', 6, 2),
(10, 'good', 3.0, '2024-11-22 16:41:40', 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `job_application_id` bigint(20) NOT NULL,
  `applied_at` datetime NOT NULL,
  `job_post_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `status_id` bigint(20) NOT NULL,
  `user_profile_id` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_applications`
--

INSERT INTO `job_applications` (`job_application_id`, `applied_at`, `job_post_id`, `user_id`, `status_id`, `user_profile_id`) VALUES
(6, '2024-11-13 03:31:17', 1, 2, 5, 2),
(7, '2024-11-13 03:31:53', 1, 2, 1, 2),
(8, '2024-11-13 03:32:28', 1, 2, 1, 2),
(9, '2024-11-13 03:36:28', 1, 2, 1, 2),
(10, '2024-11-13 03:40:58', 1, 2, 1, 2),
(11, '2024-11-13 11:40:46', 1, 2, 1, 2),
(12, '2024-11-13 11:41:28', 2, 2, 5, 2),
(13, '2024-11-13 12:50:14', 6, 3, 1, 3),
(14, '2024-11-13 16:12:17', 6, 2, 5, 2),
(15, '2024-11-20 21:23:48', 1, 2, 5, 2),
(16, '2024-11-20 21:38:10', 1, 2, 5, 2),
(17, '2024-11-20 21:58:25', 1, 2, 5, 2),
(18, '2024-11-20 22:18:58', 8, 6, 6, 6),
(19, '2024-11-21 20:24:50', 1, 2, 5, 2),
(20, '2024-11-22 12:21:47', 1, 2, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `job_application_status`
--

CREATE TABLE `job_application_status` (
  `status_id` bigint(20) NOT NULL,
  `status_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_application_status`
--

INSERT INTO `job_application_status` (`status_id`, `status_name`) VALUES
(1, 'Submit Application'),
(2, 'Under Review'),
(3, 'Shortlisted'),
(4, 'Interview'),
(5, 'Hired'),
(6, 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `job_categories`
--

CREATE TABLE `job_categories` (
  `job_category_id` bigint(20) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_categories`
--

INSERT INTO `job_categories` (`job_category_id`, `category_name`) VALUES
(1, 'gardening'),
(2, 'carpenter');

-- --------------------------------------------------------

--
-- Table structure for table `job_levels`
--

CREATE TABLE `job_levels` (
  `job_level_id` bigint(20) NOT NULL,
  `level_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_levels`
--

INSERT INTO `job_levels` (`job_level_id`, `level_name`) VALUES
(1, 'Entry Level'),
(2, 'Mid Level'),
(3, 'Advanced Level');

-- --------------------------------------------------------

--
-- Table structure for table `job_postings`
--

CREATE TABLE `job_postings` (
  `job_post_id` bigint(20) NOT NULL,
  `salary_from` int(11) NOT NULL,
  `salary_to` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date_posted` datetime NOT NULL,
  `status` enum('open','closed','draft','expired') NOT NULL DEFAULT 'open',
  `expiry_date` datetime NOT NULL,
  `available_slots` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `job_title_id` bigint(20) NOT NULL,
  `job_level_id` bigint(20) NOT NULL,
  `work_location_id` bigint(20) NOT NULL,
  `employment_type_id` bigint(20) NOT NULL,
  `job_category_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_postings`
--

INSERT INTO `job_postings` (`job_post_id`, `salary_from`, `salary_to`, `address`, `date_posted`, `status`, `expiry_date`, `available_slots`, `description`, `user_id`, `job_title_id`, `job_level_id`, `work_location_id`, `employment_type_id`, `job_category_id`) VALUES
(1, 1000, 2000, '123 st', '2024-11-10 10:59:49', 'open', '0000-00-00 00:00:00', 1, 'waley', 3, 1, 1, 2, 1, 1),
(2, 1000, 2000, '123 st', '2024-11-13 11:17:02', 'open', '0000-00-00 00:00:00', 1, 'knows how to cut tree branches', 3, 2, 1, 1, 1, 2),
(4, 2000, 5000, '123 st cavite', '2024-11-13 12:23:06', 'open', '0000-00-00 00:00:00', 1, 'knows how to cut tree branches', 3, 2, 1, 1, 1, 2),
(5, 2000, 5000, '123 st cavite', '2024-11-13 12:29:20', 'open', '0000-00-00 00:00:00', 1, 'knows how to cut tree branches', 3, 2, 1, 1, 1, 2),
(6, 2000, 5000, '123 st cavite', '2024-11-13 12:30:13', 'open', '0000-00-00 00:00:00', 1, 'dunno', 3, 1, 2, 1, 1, 1),
(7, 2000, 5000, '123 st cavite', '2024-11-13 12:51:31', 'open', '0000-00-00 00:00:00', 1, 'dunno', 3, 1, 2, 1, 1, 1),
(8, 1000, 2000, '123 st cavite city', '2024-11-20 22:18:06', 'open', '0000-00-00 00:00:00', 2, 'ewan', 7, 3, 1, 1, 1, 1),
(9, 1000, 2000, 'sdsds', '2024-11-24 09:04:49', 'open', '0000-00-00 00:00:00', 1, 'knows how to trim', 3, 1, 1, 1, 1, 1),
(10, 1000, 2000, 'sdsds', '2024-11-24 09:07:00', 'open', '0000-00-00 00:00:00', 1, 'knows how to trim', 3, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `job_seeker_skills`
--

CREATE TABLE `job_seeker_skills` (
  `job_seeker_skill_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `skill_id` bigint(20) NOT NULL,
  `skill_level_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_seeker_skills`
--

INSERT INTO `job_seeker_skills` (`job_seeker_skill_id`, `user_id`, `skill_id`, `skill_level_id`) VALUES
(1, 2, 6, 1),
(2, 2, 24, 2),
(3, 2, 33, 1),
(7, 6, 13, 1),
(8, 6, 14, 1),
(9, 6, 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `job_titles`
--

CREATE TABLE `job_titles` (
  `job_title_id` bigint(20) NOT NULL,
  `title_name` varchar(100) NOT NULL,
  `other_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_titles`
--

INSERT INTO `job_titles` (`job_title_id`, `title_name`, `other_title`) VALUES
(1, 'gardener', ''),
(2, 'carpintero', ''),
(3, 'tubero', '');

-- --------------------------------------------------------

--
-- Table structure for table `required_skills`
--

CREATE TABLE `required_skills` (
  `required_skill_id` bigint(20) NOT NULL,
  `experience_year` int(11) NOT NULL,
  `job_post_id` bigint(20) NOT NULL,
  `skill_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `required_skills`
--

INSERT INTO `required_skills` (`required_skill_id`, `experience_year`, `job_post_id`, `skill_id`) VALUES
(1, 0, 9, 2),
(2, 0, 9, 23),
(3, 0, 9, 37),
(4, 0, 10, 6),
(5, 0, 10, 24),
(6, 0, 10, 31);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `skill_id` bigint(20) NOT NULL,
  `skill_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`skill_id`, `skill_name`) VALUES
(1, 'welding'),
(2, 'concrete-work'),
(3, 'roofing'),
(4, 'carpentry'),
(5, 'masonry'),
(6, 'painting'),
(7, 'tiling'),
(8, 'demolition'),
(9, 'shoveling'),
(10, 'sanding'),
(11, 'laundry'),
(12, 'derusting'),
(13, 'gutter-cleaning'),
(14, 'pressure-washing'),
(15, 'tree-trimming'),
(16, 'pest-control'),
(17, 'sweeping'),
(18, 'surface-scrubbing'),
(19, 'mopping'),
(20, 'vacuuming'),
(21, 'dishwashing'),
(22, 'food-stocking'),
(23, 'food-preparation'),
(24, 'serving'),
(25, 'table-bussing'),
(26, 'order-taking'),
(27, 'delivering'),
(28, 'cooking'),
(29, 'bagging'),
(30, 'meat-cutting'),
(31, 'leaf-blowing'),
(32, 'planting'),
(33, 'prunning-and-trimming'),
(34, 'weeding'),
(35, 'watering'),
(36, 'copywriting'),
(37, 'graphic-design'),
(38, 'video-editing'),
(39, 'web-design'),
(40, 'photography');

-- --------------------------------------------------------

--
-- Table structure for table `skill_levels`
--

CREATE TABLE `skill_levels` (
  `skill_level_id` bigint(20) NOT NULL,
  `level_name` enum('beginner','intermediate','advanced','expert') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skill_levels`
--

INSERT INTO `skill_levels` (`skill_level_id`, `level_name`) VALUES
(1, 'beginner'),
(2, 'intermediate'),
(3, 'advanced'),
(4, 'expert');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `last_login_date` datetime NOT NULL,
  `status` enum('active','inactive','pending','suspended','deactivated') NOT NULL,
  `deleted_at` datetime NOT NULL,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `deactivated_at` datetime DEFAULT NULL,
  `reactivated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `contact_no`, `email`, `last_login_date`, `status`, `deleted_at`, `reset_token_hash`, `reset_token_expires_at`, `deactivated_at`, `reactivated_at`) VALUES
(1, 'superadmin', '$2y$10$toehMpmuftmMeY7ZFbrqieAike8TB5E8WqWTM4ktN1zH3Y3yhX81S', '1111111', 'superadmin@gmail.com', '0000-00-00 00:00:00', 'active', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL),
(2, 'bellpip', '$2y$10$wR043XF2FMuhoIgh7WB6i.IDguV5D2FLgdivpBGUogtGMeXCDSO/m', '11111111', 'bellpip.88@gmail.com', '0000-00-00 00:00:00', 'active', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL),
(3, 'mcdoofficial', '$2y$10$sWi3yg7crEt7gj9iN5umEOmOEBxT6cBzXOs/SftRWLnMiGRh1zNg2', '11111111', 'mcdo@gmail.com', '0000-00-00 00:00:00', 'active', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL),
(6, 'marco', '$2y$10$WZ8ut9xalgpL7lriZWZtQORYdAibB1ZGpAcYeD0uSHEPCauJ.9Tma', '11111', 'marco@gmail.com', '0000-00-00 00:00:00', 'active', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL),
(7, 'goofycreatives', '$2y$10$llPgE.0cqowAc6K5cBCwy.dq8YvQjVobWUNMARBjLj53eaI7WdoI6', '111111', 'goofycreatives09@gmail.com', '0000-00-00 00:00:00', 'inactive', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL),
(9, 'shell', '$2y$10$3luc5rPbvC.fhKdvkAaYR.yDvGPXY760IIE2oLAlRC2NMgRqK/6b6', '111111', 'shell@gmail.com', '0000-00-00 00:00:00', 'active', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_profile`
--

CREATE TABLE `users_profile` (
  `user_profile_id` bigint(20) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `profile_picture_url` varchar(255) NOT NULL,
  `bio` varchar(255) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `business_permit_url` varchar(255) DEFAULT NULL,
  `police_clearance_url` varchar(255) DEFAULT NULL,
  `resume_url` varchar(255) DEFAULT NULL,
  `cv_url` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_type_id` bigint(20) NOT NULL,
  `portfolio` varchar(255) DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_profile`
--

INSERT INTO `users_profile` (`user_profile_id`, `display_name`, `profile_picture_url`, `bio`, `contact_person`, `business_permit_url`, `police_clearance_url`, `resume_url`, `cv_url`, `user_id`, `user_type_id`, `portfolio`, `is_verified`) VALUES
(1, '', '', '', '', '', NULL, '../user_documents/16.docx', '../user_documents/16.docx', 1, 3, NULL, 0),
(2, 'bellpip', 'Untitled design (10).png', 'im bellpip', NULL, NULL, '../doc_validation/A Caesar cipher.pdf', '../user_documents/A Caesar cipher.pdf', '../user_documents/A Caesar cipher.pdf', 2, 1, '../user_documents/A Caesar cipher.pdf', 0),
(3, 'mcdo', 'Untitled design (9).png', 'welcome to mcdos account', 'ronald mcdonald', '../doc_validation/A Caesar cipher.pdf', NULL, '../user_documents/16.docx', '../user_documents/16.docx', 3, 2, NULL, 0),
(6, 'marco', '', '', NULL, NULL, NULL, '../user_documents/Prijoles - ACT 2.pdf', '../user_documents/Prijoles - ACT 2.pdf', 6, 1, NULL, 0),
(7, 'goofy creatives', '', '', NULL, NULL, NULL, NULL, NULL, 7, 2, NULL, 0),
(9, 'shell', '', '', 'shelly', '../doc_validation/A Caesar cipher.pdf', NULL, NULL, NULL, 9, 2, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE `user_types` (
  `user_type_id` bigint(20) NOT NULL,
  `type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`user_type_id`, `type_name`) VALUES
(1, 'Job Seeker'),
(2, 'Employer'),
(3, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `work_locations`
--

CREATE TABLE `work_locations` (
  `work_location_id` bigint(20) NOT NULL,
  `location_type` enum('onsite','remote','hybird','flexible') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `work_locations`
--

INSERT INTO `work_locations` (`work_location_id`, `location_type`) VALUES
(1, 'onsite'),
(2, 'remote'),
(3, 'hybird'),
(4, 'flexible');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_ratings`
--
ALTER TABLE `app_ratings`
  ADD PRIMARY KEY (`app_rating_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `job_post_id` (`job_post_id`),
  ADD KEY `job_application_id` (`job_application_id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`document_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `employer_ratings`
--
ALTER TABLE `employer_ratings`
  ADD PRIMARY KEY (`employer_rating_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `target_user_id` (`target_user_id`);

--
-- Indexes for table `employment_types`
--
ALTER TABLE `employment_types`
  ADD PRIMARY KEY (`employment_type_id`);

--
-- Indexes for table `jobseeker_ratings`
--
ALTER TABLE `jobseeker_ratings`
  ADD PRIMARY KEY (`jobseeker_rating_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `target_user_id` (`target_user_id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`job_application_id`),
  ADD KEY `job_post_id` (`job_post_id`),
  ADD KEY `status_id` (`status_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_profile_id` (`user_profile_id`);

--
-- Indexes for table `job_application_status`
--
ALTER TABLE `job_application_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `job_categories`
--
ALTER TABLE `job_categories`
  ADD PRIMARY KEY (`job_category_id`);

--
-- Indexes for table `job_levels`
--
ALTER TABLE `job_levels`
  ADD PRIMARY KEY (`job_level_id`);

--
-- Indexes for table `job_postings`
--
ALTER TABLE `job_postings`
  ADD PRIMARY KEY (`job_post_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `job_title_id` (`job_title_id`),
  ADD KEY `job_level_id` (`job_level_id`),
  ADD KEY `work_location_id` (`work_location_id`),
  ADD KEY `employment_type_id` (`employment_type_id`),
  ADD KEY `job_category_id` (`job_category_id`);

--
-- Indexes for table `job_seeker_skills`
--
ALTER TABLE `job_seeker_skills`
  ADD PRIMARY KEY (`job_seeker_skill_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `skill_id` (`skill_id`),
  ADD KEY `skill_level_id` (`skill_level_id`);

--
-- Indexes for table `job_titles`
--
ALTER TABLE `job_titles`
  ADD PRIMARY KEY (`job_title_id`);

--
-- Indexes for table `required_skills`
--
ALTER TABLE `required_skills`
  ADD PRIMARY KEY (`required_skill_id`),
  ADD KEY `job_post_id` (`job_post_id`),
  ADD KEY `skill_id` (`skill_id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`skill_id`);

--
-- Indexes for table `skill_levels`
--
ALTER TABLE `skill_levels`
  ADD PRIMARY KEY (`skill_level_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`);

--
-- Indexes for table `users_profile`
--
ALTER TABLE `users_profile`
  ADD PRIMARY KEY (`user_profile_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_type_id` (`user_type_id`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`user_type_id`);

--
-- Indexes for table `work_locations`
--
ALTER TABLE `work_locations`
  ADD PRIMARY KEY (`work_location_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_ratings`
--
ALTER TABLE `app_ratings`
  MODIFY `app_rating_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `document_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employer_ratings`
--
ALTER TABLE `employer_ratings`
  MODIFY `employer_rating_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employment_types`
--
ALTER TABLE `employment_types`
  MODIFY `employment_type_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobseeker_ratings`
--
ALTER TABLE `jobseeker_ratings`
  MODIFY `jobseeker_rating_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `job_application_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `job_application_status`
--
ALTER TABLE `job_application_status`
  MODIFY `status_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `job_categories`
--
ALTER TABLE `job_categories`
  MODIFY `job_category_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_levels`
--
ALTER TABLE `job_levels`
  MODIFY `job_level_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_postings`
--
ALTER TABLE `job_postings`
  MODIFY `job_post_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `job_seeker_skills`
--
ALTER TABLE `job_seeker_skills`
  MODIFY `job_seeker_skill_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `job_titles`
--
ALTER TABLE `job_titles`
  MODIFY `job_title_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `required_skills`
--
ALTER TABLE `required_skills`
  MODIFY `required_skill_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `skill_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `skill_levels`
--
ALTER TABLE `skill_levels`
  MODIFY `skill_level_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users_profile`
--
ALTER TABLE `users_profile`
  MODIFY `user_profile_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_types`
--
ALTER TABLE `user_types`
  MODIFY `user_type_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `work_locations`
--
ALTER TABLE `work_locations`
  MODIFY `work_location_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `app_ratings`
--
ALTER TABLE `app_ratings`
  ADD CONSTRAINT `app_ratings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `app_ratings_ibfk_2` FOREIGN KEY (`job_post_id`) REFERENCES `job_postings` (`job_post_id`),
  ADD CONSTRAINT `app_ratings_ibfk_3` FOREIGN KEY (`job_application_id`) REFERENCES `job_applications` (`job_application_id`);

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `employer_ratings`
--
ALTER TABLE `employer_ratings`
  ADD CONSTRAINT `employer_ratings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `employer_ratings_ibfk_2` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `jobseeker_ratings`
--
ALTER TABLE `jobseeker_ratings`
  ADD CONSTRAINT `jobseeker_ratings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `jobseeker_ratings_ibfk_2` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD CONSTRAINT `job_applications_ibfk_1` FOREIGN KEY (`job_post_id`) REFERENCES `job_postings` (`job_post_id`),
  ADD CONSTRAINT `job_applications_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `job_application_status` (`status_id`),
  ADD CONSTRAINT `job_applications_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `job_applications_ibfk_4` FOREIGN KEY (`user_profile_id`) REFERENCES `users_profile` (`user_profile_id`);

--
-- Constraints for table `job_postings`
--
ALTER TABLE `job_postings`
  ADD CONSTRAINT `job_postings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `job_postings_ibfk_2` FOREIGN KEY (`job_title_id`) REFERENCES `job_titles` (`job_title_id`),
  ADD CONSTRAINT `job_postings_ibfk_3` FOREIGN KEY (`job_level_id`) REFERENCES `job_levels` (`job_level_id`),
  ADD CONSTRAINT `job_postings_ibfk_4` FOREIGN KEY (`work_location_id`) REFERENCES `work_locations` (`work_location_id`),
  ADD CONSTRAINT `job_postings_ibfk_5` FOREIGN KEY (`employment_type_id`) REFERENCES `employment_types` (`employment_type_id`),
  ADD CONSTRAINT `job_postings_ibfk_6` FOREIGN KEY (`job_category_id`) REFERENCES `job_categories` (`job_category_id`);

--
-- Constraints for table `job_seeker_skills`
--
ALTER TABLE `job_seeker_skills`
  ADD CONSTRAINT `job_seeker_skills_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `job_seeker_skills_ibfk_2` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`skill_id`),
  ADD CONSTRAINT `job_seeker_skills_ibfk_3` FOREIGN KEY (`skill_level_id`) REFERENCES `skill_levels` (`skill_level_id`);

--
-- Constraints for table `required_skills`
--
ALTER TABLE `required_skills`
  ADD CONSTRAINT `required_skills_ibfk_1` FOREIGN KEY (`job_post_id`) REFERENCES `job_postings` (`job_post_id`),
  ADD CONSTRAINT `required_skills_ibfk_2` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`skill_id`);

--
-- Constraints for table `users_profile`
--
ALTER TABLE `users_profile`
  ADD CONSTRAINT `users_profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `users_profile_ibfk_2` FOREIGN KEY (`user_type_id`) REFERENCES `user_types` (`user_type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
